package com.ginger.controller;

import com.ginger.pojo.Result;
import com.ginger.pojo.User;
import com.ginger.service.LoginService;
import com.ginger.service.impl.LoginServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
public class LoginController {
    @Autowired
    private LoginService loginService;
    @PostMapping("/login")
    public Result login(@RequestParam String username, @RequestParam String password) {
       User user = loginService.login(username, password);
       if (user != null) {
           return Result.success(user);
       }
       return Result.error("wrong username or password");
    }
}
