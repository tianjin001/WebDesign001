package com.ginger.controller;

import com.ginger.pojo.Dept;
import com.ginger.pojo.Result;
import com.ginger.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DeptController {
    @Autowired
    private DeptService deptService; //注入Service
    @RequestMapping(value = "/depts" , method = RequestMethod.GET)
    //@GetMapping("/depts")
    public Result getDeptList(){
        System.out.println("查询所有！");
        List<Dept> deptList = deptService.findAll(); //调用Service的方法 结果封装到Dept实体类中
        return Result.success(deptList);             //调用Result的方法
    }
}
