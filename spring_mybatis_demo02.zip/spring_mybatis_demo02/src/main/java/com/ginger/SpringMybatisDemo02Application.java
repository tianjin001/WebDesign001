package com.ginger;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.ginger.mapper")
public class SpringMybatisDemo02Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringMybatisDemo02Application.class, args);
    }

}
