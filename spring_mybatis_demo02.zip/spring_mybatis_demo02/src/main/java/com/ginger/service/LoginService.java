package com.ginger.service;

import com.ginger.pojo.User;

public interface LoginService {
     User login(String username, String password);
}
