package com.ginger.service.impl;

import com.ginger.mapper.DeptMapper;
import com.ginger.pojo.Dept;
import com.ginger.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeptServiceImpl implements DeptService {
    @Autowired
    private DeptMapper deptMapper;        //注入mapper

    @Override
    public List<Dept> findAll() {         //方法重写 Service的具体实现
        return deptMapper.selectAll();    //调用mapper的方法
    }
}
