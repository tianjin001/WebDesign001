package com.ginger.service;

import com.ginger.pojo.Dept;

import java.util.List;

public interface DeptService {

    List<Dept> findAll();    //逻辑处理 定义方法
}
