package com.ginger.service.impl;

import com.ginger.mapper.UserMapper;
import com.ginger.pojo.User;
import com.ginger.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements LoginService {
    @Autowired
    private UserMapper userMapper;

    @Override
    public User login(String username, String password){
        return userMapper.select(username,password);
    }
}
